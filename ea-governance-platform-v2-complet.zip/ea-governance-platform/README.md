# EA Governance Platform V2 — CRM / BIAN / SI

Plateforme web enterprise-grade pour transformer les fichiers Excel **Matrice Capability / Processus / SI CRM** et **BIAN v14** en repository d’architecture d’entreprise bancaire.

## Modules livrés
- Import Excel intelligent via Apache POI.
- Référentiel BIAN : Business Area, Business Domain, Service Domain.
- Référentiel processus CRM/CBS/HUB.
- Matrice Enterprise : Processus × BIAN × SI × rôles applicatifs.
- Application Portfolio Management.
- API & Integration Repository.
- Gouvernance : principes, ADR, DAB, actions.
- Roadmap transformation.
- Frontend cockpit React avec dashboard, matrices, graphes React Flow.
- Backend Spring Boot 3 / Java 21 / H2 / PostgreSQL-ready.
- Docker Compose, CI GitHub Actions.

## Démarrage
```bash
cd backend
mvn spring-boot:run
```
Swagger : http://localhost:8080/swagger-ui.html

```bash
cd frontend
npm install
npm run dev
```
Frontend : http://localhost:5173

## Import
Endpoint : `POST /api/import/excel`

Fichiers cibles :
- `Copie de Matrice_Capability_Processus_SI CRM_190526.xlsx`
- `BIAN_v14_Referentiel.xlsx`

## Roadmap immédiate
1. Brancher PostgreSQL.
2. Ajouter JWT/RBAC effectif.
3. Stabiliser le mapping automatique des colonnes Excel.
4. Ajouter tests unitaires et tests d’intégration.
5. Ajouter génération PowerPoint/PDF pour DAB.
6. Ajouter assistant IA/RAG.
