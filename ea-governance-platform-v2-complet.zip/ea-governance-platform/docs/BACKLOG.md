# Backlog produit

## Epic 1 — Import Excel intelligent
- En tant qu’architecte, je veux importer la matrice Excel afin d’alimenter automatiquement le référentiel.
- En tant qu’architecte, je veux détecter les doublons, lignes vides et mappings incohérents.
- En tant qu’architecte, je veux comparer deux imports pour identifier les évolutions.

## Epic 2 — Référentiel BIAN
- Gérer Business Areas, Business Domains, Service Domains.
- Calculer la couverture BIAN par processus/application.
- Afficher une heatmap BIAN.

## Epic 3 — Matrice Architecture
- Afficher Processus × BIAN × Applications.
- Filtrer par CRM/CBS/HUB/GED/MDM/Data.
- Gérer les rôles Init, Orch, Proc, Master, Restit.

## Epic 4 — Dashboard exécutif
- KPIs couverture BIAN.
- KPIs dette fonctionnelle.
- KPIs redondance et urbanisation.

## Epic 5 — Gouvernance DAB
- Préparer comité.
- Générer CR.
- Suivre décisions et actions.

## Epic 6 — Analyse d’impact
- Simuler changement application/API/processus.
- Visualiser impacts métier, SI, data et sécurité.

## Epic 7 — Assistant IA Architecte
- Proposer mapping BIAN.
- Détecter incohérences.
- Générer synthèses architecture.
