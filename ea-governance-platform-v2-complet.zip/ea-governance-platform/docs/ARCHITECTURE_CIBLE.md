# Architecture cible

## Vision
La solution devient un Architecture Repository bancaire aligné TOGAF / BIAN, orienté gouvernance, cartographie, analyse d’impact et pilotage de transformation.

## Bounded Contexts DDD
1. **Import Context** : ingestion Excel, contrôles qualité, historisation.
2. **BIAN Context** : Business Areas, Business Domains, Service Domains, couverture.
3. **Process Context** : processus, sous-processus, acteurs, capacités.
4. **Application Portfolio Context** : applications, rôles, criticité, lifecycle.
5. **Integration Context** : APIs, flux, events, batch, MFT.
6. **Governance Context** : ADR, principes, DAB, validations, exceptions.
7. **Impact Analysis Context** : graphe de dépendances et simulation.
8. **AI Architect Context** : assistant de mapping, contrôle qualité, génération CR.

## Vue C4 — Container
- React SPA : cockpit architecture.
- Spring Boot API : API REST, sécurité, règles métier.
- PostgreSQL : référentiel persistant.
- Redis : cache et sessions.
- Object Storage : documents importés/exportés.
- AI/RAG Engine : moteur IA futur.

## Roadmap
- V1 : import Excel, dashboard, matrice interactive.
- V2 : gouvernance DAB, ADR, workflows.
- V3 : cartographie graphique, impact analysis.
- V4 : agents IA, RAG, recommandations.
- V5 : connecteurs MEGA/JIRA/Confluence/ArchiMate.
