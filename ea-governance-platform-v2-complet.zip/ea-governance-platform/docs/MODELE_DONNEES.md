# Modèle de données V2

## Domaines fonctionnels

### BIAN
- BianBusinessArea
- BianBusinessDomain
- BianServiceDomain
- BianApi

### Business Architecture
- Capability
- BusinessProcess
- SubProcess à modéliser en extension
- Actor / BusinessRole à modéliser en extension

### Application Architecture
- ApplicationComponent
- ApplicationService
- ApiAsset
- IntegrationFlow
- EventTopic

### Data Architecture
- DataEntity
- MasterData / GoldenRecord via attributs `masterData` et `goldenSource`

### Governance
- ArchitecturePrinciple
- ArchitectureDecisionRecord
- GovernanceCommittee
- GovernanceAction

### Transformation
- Initiative
- WorkPackage

### Audit / Import
- ImportBatch
- AuditLog
- ApplicationRoleMapping

## Relations cibles à implémenter ensuite
- Capability N:N BusinessProcess
- BusinessProcess N:N BianServiceDomain
- BusinessProcess N:N ApplicationComponent
- ApplicationComponent 1:N ApiAsset
- ApplicationComponent 1:N IntegrationFlow
- ApplicationComponent N:N DataEntity
- ADR N:N Capability / Application / Process
- Initiative N:N Capability / Application
