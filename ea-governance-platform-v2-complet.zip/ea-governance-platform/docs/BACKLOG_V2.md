# Backlog V2 détaillé

## Sprint 1 — Foundation
- Corriger compilation backend et packaging.
- Ajouter modèle de données public par entité.
- Ajouter endpoints repository principaux.
- Ajouter frontend cockpit multi-vues.

## Sprint 2 — Import Excel robuste
- Détection automatique des feuilles.
- Détection automatique des headers.
- Mapping colonne configurable.
- Rapport qualité détaillé.
- Comparaison entre imports.

## Sprint 3 — BIAN Repository
- Import BIAN v14 dédié.
- Heatmap BIAN.
- Couverture processus/applications.
- Suggestions de mapping.

## Sprint 4 — Gouvernance
- ADR complet.
- Architecture principles.
- DAB agendas/actions/décisions.
- Workflow de validation.

## Sprint 5 — Digital Twin
- Graphe dépendances processus/applications/APIs/flux/données.
- Simulation d’impact.
- Roadmap de transformation.

## Sprint 6 — IA
- Agent BIAN.
- Agent Urbanisation.
- Agent DAB.
- RAG sur repository architecture.
