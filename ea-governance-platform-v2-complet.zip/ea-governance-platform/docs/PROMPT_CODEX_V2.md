# Prompt Codex V2

Continue ce projet comme une plateforme enterprise d’architecture bancaire alignée TOGAF/BIAN.

Priorités :
1. rendre le backend compilable et testé,
2. finaliser les repositories CRUD,
3. ajouter DTO/Mapper/Service par bounded context,
4. améliorer l’import Excel avec mapping dynamique,
5. enrichir le frontend avec AG Grid, React Query, React Router,
6. ajouter sécurité JWT/RBAC,
7. ajouter PostgreSQL + Flyway,
8. ajouter génération DAB PDF/PPT,
9. ajouter IA/RAG pour suggestions BIAN et analyse d’impact.

Respecter : Clean Architecture, DDD, API-first, observabilité, DevSecOps.
