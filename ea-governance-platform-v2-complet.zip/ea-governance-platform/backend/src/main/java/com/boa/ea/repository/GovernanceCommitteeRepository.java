package com.boa.ea.repository;
import com.boa.ea.domain.GovernanceCommittee;
import org.springframework.data.jpa.repository.JpaRepository;
public interface GovernanceCommitteeRepository extends JpaRepository<GovernanceCommittee, Long> {
}
