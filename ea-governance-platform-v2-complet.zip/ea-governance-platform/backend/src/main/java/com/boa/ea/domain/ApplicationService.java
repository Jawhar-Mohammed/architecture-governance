package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class ApplicationService {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String applicationCode; private String serviceName; private String serviceType; @Column(length=4000) private String description;
}
