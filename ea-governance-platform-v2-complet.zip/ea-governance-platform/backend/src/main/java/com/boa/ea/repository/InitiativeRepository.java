package com.boa.ea.repository;
import com.boa.ea.domain.Initiative;
import org.springframework.data.jpa.repository.JpaRepository;
public interface InitiativeRepository extends JpaRepository<Initiative, Long> {
}
