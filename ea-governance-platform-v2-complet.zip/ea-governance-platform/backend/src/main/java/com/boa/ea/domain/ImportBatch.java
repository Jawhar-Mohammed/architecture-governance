package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class ImportBatch {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String fileName; private java.time.Instant importedAt; private Integer bianRows; private Integer processRows; private Integer mappingRows; @Column(length=4000) private String qualityReport;
}
