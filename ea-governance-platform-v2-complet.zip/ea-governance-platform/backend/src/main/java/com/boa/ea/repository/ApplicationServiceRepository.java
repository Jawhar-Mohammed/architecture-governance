package com.boa.ea.repository;
import com.boa.ea.domain.ApplicationService;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ApplicationServiceRepository extends JpaRepository<ApplicationService, Long> {
}
