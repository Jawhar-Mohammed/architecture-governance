package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class GovernanceAction {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String title; private String owner; private String dueDate; private String status; private String relatedDecision; @Column(length=4000) private String description;
}
