package com.boa.ea.repository;
import com.boa.ea.domain.DataEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface DataEntityRepository extends JpaRepository<DataEntity, Long> {
}
