package com.boa.ea.repository;
import com.boa.ea.domain.GovernanceAction;
import org.springframework.data.jpa.repository.JpaRepository;
public interface GovernanceActionRepository extends JpaRepository<GovernanceAction, Long> {
}
