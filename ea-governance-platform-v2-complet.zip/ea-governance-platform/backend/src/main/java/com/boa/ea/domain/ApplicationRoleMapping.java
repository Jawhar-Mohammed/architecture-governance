package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class ApplicationRoleMapping {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String businessArea; private String businessDomain; private String serviceDomain; private String process; private String subProcess; private String applicationBrick; private String roleName; private String roleValue; private String sourceSheet;
}
