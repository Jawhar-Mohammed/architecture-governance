package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class BianServiceDomain {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String businessArea; private String businessDomain; @Column(unique=true) private String serviceDomain; @Column(length=4000) private String description; private String statusV14;
}
