package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class ApiAsset {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String apiName; private String apiType; private String providerApplication; private String consumerApplication; private String securityScheme; private String lifecycle; private String swaggerUrl;
}
