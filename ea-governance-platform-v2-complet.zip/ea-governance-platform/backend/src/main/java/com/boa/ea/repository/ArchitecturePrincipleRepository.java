package com.boa.ea.repository;
import com.boa.ea.domain.ArchitecturePrinciple;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ArchitecturePrincipleRepository extends JpaRepository<ArchitecturePrinciple, Long> {
}
