package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class GovernanceCommittee {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String committeeName; private String meetingDate; private String status; @Column(length=4000) private String agenda; @Column(length=4000) private String minutes;
}
