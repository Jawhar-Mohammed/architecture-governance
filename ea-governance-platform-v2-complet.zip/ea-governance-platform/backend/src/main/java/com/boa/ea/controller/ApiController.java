package com.boa.ea.controller;
import com.boa.ea.domain.*;
import com.boa.ea.repository.*;
import com.boa.ea.service.ExcelImportService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.*;

@RestController @RequestMapping("/api") @RequiredArgsConstructor
public class ApiController {
  private final ExcelImportService importService;
  private final BianServiceDomainRepository bianRepo; private final BusinessProcessRepository processRepo; private final ApplicationRoleMappingRepository mappingRepo; private final ImportBatchRepository batchRepo;
  private final ApplicationComponentRepository appRepo; private final ApiAssetRepository apiRepo; private final IntegrationFlowRepository flowRepo; private final CapabilityRepository capabilityRepo;
  private final ArchitecturePrincipleRepository principleRepo; private final ArchitectureDecisionRecordRepository adrRepo; private final GovernanceActionRepository actionRepo; private final InitiativeRepository initiativeRepo;
  @PostMapping("/import/excel") public ImportBatch importExcel(@RequestParam MultipartFile file) throws Exception { return importService.importExcel(file); }
  @GetMapping("/bian/service-domains") public List<BianServiceDomain> bian(){ return bianRepo.findAll(); }
  @GetMapping("/processes") public List<BusinessProcess> processes(){ return processRepo.findAll(); }
  @GetMapping("/mappings") public List<ApplicationRoleMapping> mappings(){ return mappingRepo.findAll(); }
  @GetMapping("/applications") public List<ApplicationComponent> applications(){ return appRepo.findAll(); }
  @GetMapping("/apis") public List<ApiAsset> apis(){ return apiRepo.findAll(); }
  @GetMapping("/flows") public List<IntegrationFlow> flows(){ return flowRepo.findAll(); }
  @GetMapping("/capabilities") public List<Capability> capabilities(){ return capabilityRepo.findAll(); }
  @GetMapping("/principles") public List<ArchitecturePrinciple> principles(){ return principleRepo.findAll(); }
  @GetMapping("/adr") public List<ArchitectureDecisionRecord> adr(){ return adrRepo.findAll(); }
  @GetMapping("/actions") public List<GovernanceAction> actions(){ return actionRepo.findAll(); }
  @GetMapping("/initiatives") public List<Initiative> initiatives(){ return initiativeRepo.findAll(); }
  @GetMapping("/imports") public List<ImportBatch> imports(){ return batchRepo.findAll(); }
  @GetMapping("/dashboard") public Map<String,Object> dashboard(){ Map<String,Object> m=new LinkedHashMap<>(); m.put("serviceDomains", bianRepo.count()); m.put("processes", processRepo.count()); m.put("roleMappings", mappingRepo.count()); m.put("imports", batchRepo.count()); m.put("applications", appRepo.count()); m.put("apis", apiRepo.count()); m.put("flows", flowRepo.count()); m.put("capabilities", capabilityRepo.count()); m.put("adr", adrRepo.count()); m.put("actions", actionRepo.count()); m.put("initiatives", initiativeRepo.count()); return m; }
  @PostMapping("/applications") public ApplicationComponent saveApp(@RequestBody ApplicationComponent v){ return appRepo.save(v); }
  @PostMapping("/capabilities") public Capability saveCapability(@RequestBody Capability v){ return capabilityRepo.save(v); }
  @PostMapping("/adr") public ArchitectureDecisionRecord saveAdr(@RequestBody ArchitectureDecisionRecord v){ return adrRepo.save(v); }
}
