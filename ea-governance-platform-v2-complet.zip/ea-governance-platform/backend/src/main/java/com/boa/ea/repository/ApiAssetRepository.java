package com.boa.ea.repository;
import com.boa.ea.domain.ApiAsset;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ApiAssetRepository extends JpaRepository<ApiAsset, Long> {
}
