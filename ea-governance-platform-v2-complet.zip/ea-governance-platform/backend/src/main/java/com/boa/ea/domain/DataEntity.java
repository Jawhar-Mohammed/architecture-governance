package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class DataEntity {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String domain; private String entityName; private String owner; private String classification; private Boolean masterData; private String goldenSource;
}
