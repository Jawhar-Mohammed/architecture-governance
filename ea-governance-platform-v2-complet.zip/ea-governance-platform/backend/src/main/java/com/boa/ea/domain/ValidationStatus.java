package com.boa.ea.domain;
public enum ValidationStatus { DRAFT, TO_REVIEW, APPROVED, REJECTED, ARCHIVED }
