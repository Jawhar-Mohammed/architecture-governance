package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class ApplicationComponent {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String code; private String name; private String domain; private String owner; private String criticality; private String lifecycle; private String hosting; private String cloudReadiness; private Double annualCost;
}
