package com.boa.ea.repository;
import com.boa.ea.domain.ApplicationComponent;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ApplicationComponentRepository extends JpaRepository<ApplicationComponent, Long> {
}
