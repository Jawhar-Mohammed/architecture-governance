package com.boa.ea.repository;
import com.boa.ea.domain.BianBusinessDomain;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BianBusinessDomainRepository extends JpaRepository<BianBusinessDomain, Long> {
}
