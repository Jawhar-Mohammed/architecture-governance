package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class BianApi {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String serviceDomain; private String apiName; private String operationName; private String pattern; private String version;
}
