package com.boa.ea.repository;
import com.boa.ea.domain.BianServiceDomain;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BianServiceDomainRepository extends JpaRepository<BianServiceDomain, Long> {
  java.util.Optional<BianServiceDomain> findByServiceDomain(String serviceDomain);
}
