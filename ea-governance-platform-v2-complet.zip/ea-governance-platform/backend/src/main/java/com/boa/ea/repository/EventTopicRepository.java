package com.boa.ea.repository;
import com.boa.ea.domain.EventTopic;
import org.springframework.data.jpa.repository.JpaRepository;
public interface EventTopicRepository extends JpaRepository<EventTopic, Long> {
}
