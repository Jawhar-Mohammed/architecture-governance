package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class BianBusinessDomain {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String code; private String name; private String businessAreaCode; @Column(length=4000) private String description;
}
