package com.boa.ea.repository;
import com.boa.ea.domain.BianBusinessArea;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BianBusinessAreaRepository extends JpaRepository<BianBusinessArea, Long> {
}
