package com.boa.ea.repository;
import com.boa.ea.domain.Capability;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CapabilityRepository extends JpaRepository<Capability, Long> {
}
