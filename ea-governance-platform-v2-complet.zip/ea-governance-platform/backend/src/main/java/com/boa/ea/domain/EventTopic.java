package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class EventTopic {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String topicName; private String producer; private String consumer; private String eventType; private String payloadSchema;
}
