package com.boa.ea.repository;
import com.boa.ea.domain.BianApi;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BianApiRepository extends JpaRepository<BianApi, Long> {
}
