package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class ArchitecturePrinciple {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String code; private String title; @Column(length=4000) private String statement; @Column(length=4000) private String rationale; @Column(length=4000) private String implications; private String status;
}
