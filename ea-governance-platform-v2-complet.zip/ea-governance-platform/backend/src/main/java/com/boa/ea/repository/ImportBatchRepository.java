package com.boa.ea.repository;
import com.boa.ea.domain.ImportBatch;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ImportBatchRepository extends JpaRepository<ImportBatch, Long> {
}
