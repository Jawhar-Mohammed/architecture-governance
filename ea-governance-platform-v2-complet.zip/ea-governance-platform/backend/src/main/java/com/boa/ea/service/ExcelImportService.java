package com.boa.ea.service;

import com.boa.ea.domain.*;
import com.boa.ea.repository.*;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.time.Instant;
import java.util.*;

@Service @RequiredArgsConstructor
public class ExcelImportService {
  private final BianServiceDomainRepository bianRepo;
  private final BusinessProcessRepository processRepo;
  private final ApplicationRoleMappingRepository mappingRepo;
  private final ImportBatchRepository batchRepo;

  private static final List<String> MATRIX_SHEETS = List.of("2. Matrice PROCESSUS CBS", "3. Matrice PROCESSUS  HUB", "4. Matrice PROCESSUS  CRM", "Matrice PROCESSUS CRM");
  private static final List<String> BRICKS = List.of("CRM","CBS","HUB","GED","MDM","Workflow","Comptabilite","Editique","Data");
  private static final List<String> ROLES = List.of("Initiation","Orchestration","Execution","Referentiel","Reporting");

  public ImportBatch importExcel(MultipartFile file) throws Exception {
    int bianRows=0, processRows=0, mappingRows=0;
    try (Workbook wb = WorkbookFactory.create(file.getInputStream())) {
      Sheet bian = firstSheet(wb, "BIAN", "Service Domains", "BIAN v14");
      if (bian != null) bianRows = importBian(bian);
      for (String sheetName : MATRIX_SHEETS) {
        Sheet sheet = wb.getSheet(sheetName);
        if (sheet != null) { int[] c = importMatrix(sheet, sheetName); processRows += c[0]; mappingRows += c[1]; }
      }
    }
    return batchRepo.save(ImportBatch.builder().fileName(file.getOriginalFilename()).importedAt(Instant.now())
      .bianRows(bianRows).processRows(processRows).mappingRows(mappingRows)
      .qualityReport("Import V2 : BIAN="+bianRows+", processus="+processRows+", mappings="+mappingRows+". Contrôles qualité activés au niveau repository.").build());
  }

  private int importBian(Sheet sheet) {
    int count=0;
    for (int r=1; r<=sheet.getLastRowNum(); r++) {
      Row row=sheet.getRow(r); if(row==null) continue;
      String sd = firstNonBlank(row, 3, 2, 0); if (sd.isBlank() || sd.equalsIgnoreCase("Service Domain")) continue;
      String ba = firstNonBlank(row, 1, 0); String bd = firstNonBlank(row, 2, 1); String desc = firstNonBlank(row, 4, 5);
      bianRepo.findByServiceDomain(sd).orElseGet(() -> bianRepo.save(BianServiceDomain.builder().businessArea(ba).businessDomain(bd).serviceDomain(sd).description(desc).statusV14(firstNonBlank(row,5,6)).build()));
      count++;
    }
    return count;
  }

  private int[] importMatrix(Sheet sheet, String sourceSheet) {
    int processes=0, mappings=0;
    for (int r=3; r<=sheet.getLastRowNum(); r++) {
      Row row=sheet.getRow(r); if(row==null) continue;
      String process = firstNonBlank(row,5,4,3); if (process.isBlank() || process.toLowerCase().contains("process")) continue;
      processRepo.save(BusinessProcess.builder().domainCdc(cell(row,3)).activityCdc(cell(row,4)).process(process).subProcess(cell(row,6))
        .actors(cell(row,7)).interfacesSi(cell(row,8)).sourceSheet(sourceSheet).comment(firstNonBlank(row,54,55,56)).validationStatus(ValidationStatus.DRAFT).build());
      processes++;
      int col=9;
      for (String brick: BRICKS) for (String role: ROLES) {
        String val=cell(row,col++); if(!val.isBlank() && !val.equals("—") && !val.equals("-")) {
          mappingRepo.save(ApplicationRoleMapping.builder().businessArea(cell(row,0)).businessDomain(cell(row,1)).serviceDomain(cell(row,2))
            .process(process).subProcess(cell(row,6)).applicationBrick(brick).roleName(role).roleValue(val).sourceSheet(sourceSheet).build()); mappings++;
        }
      }
    }
    return new int[]{processes,mappings};
  }
  private static Sheet firstSheet(Workbook wb, String... names){ for(String n:names){ Sheet s=wb.getSheet(n); if(s!=null) return s;} return null; }
  private static String firstNonBlank(Row row, int... idx){ for(int i:idx){ String v=cell(row,i); if(!v.isBlank()) return v;} return ""; }
  private static String cell(Row row, int index){ Cell c=row.getCell(index); if(c==null) return ""; DataFormatter f=new DataFormatter(); return f.formatCellValue(c).trim(); }
}
