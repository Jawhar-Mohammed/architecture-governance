package com.boa.ea.repository;
import com.boa.ea.domain.ApplicationRoleMapping;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ApplicationRoleMappingRepository extends JpaRepository<ApplicationRoleMapping, Long> {
}
