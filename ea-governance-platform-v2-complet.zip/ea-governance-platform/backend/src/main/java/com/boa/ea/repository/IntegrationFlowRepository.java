package com.boa.ea.repository;
import com.boa.ea.domain.IntegrationFlow;
import org.springframework.data.jpa.repository.JpaRepository;
public interface IntegrationFlowRepository extends JpaRepository<IntegrationFlow, Long> {
}
