package com.boa.ea.repository;
import com.boa.ea.domain.ArchitectureDecisionRecord;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ArchitectureDecisionRecordRepository extends JpaRepository<ArchitectureDecisionRecord, Long> {
}
