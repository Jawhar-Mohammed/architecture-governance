package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class BusinessProcess {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String domainCdc; private String activityCdc; private String process; @Column(length=4000) private String subProcess; private String actors; private String interfacesSi; private String sourceSheet; @Enumerated(EnumType.STRING) private ValidationStatus validationStatus = ValidationStatus.DRAFT; @Column(length=4000) private String comment;
}
