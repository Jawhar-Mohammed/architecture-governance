package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class ArchitectureDecisionRecord {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String code; private String title; @Column(length=4000) private String context; @Column(length=4000) private String decision; @Column(length=4000) private String consequences; @Enumerated(EnumType.STRING) private ValidationStatus status = ValidationStatus.DRAFT;
}
