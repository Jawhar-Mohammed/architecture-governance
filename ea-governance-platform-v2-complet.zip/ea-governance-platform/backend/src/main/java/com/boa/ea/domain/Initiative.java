package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class Initiative {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String code; private String name; private String workstream; private String startDate; private String endDate; private String status; @Column(length=4000) private String description;
}
