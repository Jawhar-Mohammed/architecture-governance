package com.boa.ea.repository;
import com.boa.ea.domain.WorkPackage;
import org.springframework.data.jpa.repository.JpaRepository;
public interface WorkPackageRepository extends JpaRepository<WorkPackage, Long> {
}
