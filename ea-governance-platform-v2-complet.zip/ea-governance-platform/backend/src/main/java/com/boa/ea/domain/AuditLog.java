package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class AuditLog {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String actor; private String action; private String entityType; private Long entityId; private java.time.Instant createdAt; @Column(length=4000) private String details;
}
