package com.boa.ea.domain;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder @Entity
public class IntegrationFlow {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  private String flowName; private String sourceApplication; private String targetApplication; private String pattern; private String protocol; private String frequency; private String criticality; private String sla;
}
