package com.boa.ea.repository;
import com.boa.ea.domain.BusinessProcess;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BusinessProcessRepository extends JpaRepository<BusinessProcess, Long> {
}
