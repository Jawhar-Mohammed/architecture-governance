#!/usr/bin/env bash
set -e
(cd backend && mvn spring-boot:run) &
(cd frontend && npm install && npm run dev) &
wait
